# Simple Weather App
The project explains about simple weather app with the opensource api to get real time weather conditions.

