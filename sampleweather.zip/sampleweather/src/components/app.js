//=================
// Import the dependencies that this component will need
// to function properly
//=================
import React, { Component } from "react";

//=================
// This is the component we'll be exporting into the
// #app element on the index.html file.
//=================
export default class App extends Component {
	constructor(props) {
    super(props);
    this.state = {
    	weatherData : ""
    }
  }

  componentDidMount() {
    this.getWeatherData();
  }

  getWeatherData(){
    let getWeatherUrl = `http://api.openweathermap.org/data/2.5/weather?q=Bangalore,in&id=1277333&APPID=7d821dd15f6ed6cd91d959bc2d34a8ec`;
    fetch(getWeatherUrl)
      .then(response => response.json())
      .then(result => {
      	  this.setState({ weatherData: result });
          console.log(this.state.weatherData);
      })
    .catch(err => console.log(err));
  }

  getWeatherContent(){
  	if(this.state.weatherData !== ""){
     // return this.state.weatherData.name;
  	/*}else{
  		return "No data";
  	}*/
  	return (
  		<div class="main-div">
	      <div  className="weathericon">
          <img src={`http://openweathermap.org/img/w/${this.state.weatherData.weather[0].icon}.png`} /> 
	      </div>

	       <h2 className="weathertype text-center">{this.state.weatherData.weather[0].main}</h2>

			  <div className="wrap">
			    <div className="locationdiv">

			      <p className="location">{this.state.weatherData.name}</p>
			    </div>

			    <div className="temperaturediv">
			      <p className="temperature">{Math.round((this.state.weatherData.main.temp) / 10) + "°С"}</p>
			    </div>
			  </div> 

			  <div className="wrap2">
			    <div className="humiditydiv">
			      <p className="humidity"> <img src="src/images/humi.png" /> {this.state.weatherData.main.humidity + "%"} </p>
			    </div>

			    <div className="windspeeddiv">
			      <p className="windspeed"> <img src="src/images/win.svg" /> {this.state.weatherData.wind.speed + "m/s"} </p>
			    </div>
			  </div>
      </div>
    );
  }
}

  render() {
  	console.log(this.state.weatherData);
    return (
      <div class="">
      {this.getWeatherContent()}
      </div>
    );
  }
}
